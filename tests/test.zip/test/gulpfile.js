'use strict';

const gulp = require('gulp');
const jscs = require('gulp-jscs');

gulp.task('default', () => {
    return gulp.src('public/js/**/*.js')
        .pipe(jscs({fix: false}))
        .pipe(jscs.reporter());
});