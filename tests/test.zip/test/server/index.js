var express = require('express'),
    config = require('./config'),
    path = require('path');

var app = express();

var static_options = {
    "dotfiles": "ignore"
};

app.use('/',
    express.static(config.dir.bower, static_options),
    express.static(config.dir.public, static_options),
    express.static(config.dir.views, static_options)
);

app.get('/', function(req, res){
    res.sendFile(path.join(config.dir.views, 'index.html'));
});

app.get('/ajax/marker', function(req, res){
    
    var svgMarker = 'data:image/svg+xml;charset=UTF-8,';
    svgMarker += '%3Csvg version%3D%221.1%22%0A%09 xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 xmlns%3Axlink%3D%22http%3A%2F%2Fwww.w3.org%2F1999%2Fxlink%22%0A%09 x%3D%220px%22 y%3D%220px%22 width%3D%2242px%22 height%3D%2242px%22 viewBox%3D%22%2D0.5 %2D0.5 42 42%22 enable%2Dbackground%3D%22new %2D0.5 %2D0.5 42 42%22%0A%09 xml%3Aspace%3D%22preserve%22%3E%0A%3Cg transform%3D%22rotate%28%5Brotate%5D%2C 21%2C 21%29%22%3E%0A%3Cpath opacity%3D%220.4%22 fill%3D%22%23FFFFFF%22 enable%2Dbackground%3D%22new    %22 d%3D%22M20.5%2C18.117c0.748%2C0%2C1.359%2C0.271%2C1.904%2C0.613l6.119%2D13.057%0A%09C26.145%2C4.45%2C23.355%2C3.77%2C20.5%2C3.77c%2D2.856%2C0%2D5.644%2C0.68%2D8.024%2C1.904l6.12%2C13.057C19.072%2C18.389%2C19.752%2C18.117%2C20.5%2C18.117z%22%2F%3E%0A%3Cpath opacity%3D%220.4%22 fill%3D%22none%22 stroke%3D%22%23EC2727%22 stroke%2Dmiterlimit%3D%2210%22 enable%2Dbackground%3D%22new    %22 d%3D%22M20.5%2C18.117%0A%09c0.748%2C0%2C1.359%2C0.271%2C1.904%2C0.613l6.119%2D13.057C26.145%2C4.45%2C23.355%2C3.77%2C20.5%2C3.77c%2D2.856%2C0%2D5.644%2C0.68%2D8.024%2C1.904l6.12%2C13.057%0A%09C19.072%2C18.389%2C19.752%2C18.117%2C20.5%2C18.117z%22%2F%3E%0A%3C%2Fg%3E%0A%3C%2Fsvg%3E';
    
    res.json({
        svgMarker: svgMarker
    });
});

module.exports = app;
