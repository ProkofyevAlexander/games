var fs = require('fs'),
    path = require('path');

var config = module.exports;

config.express = {
    port: process.env.EXPRESS_PORT || 8080,
    ip: '0.0.0.0'
};

var dir_base = path.join(__dirname, '..');

config.dir = {
    base: dir_base,
    bower: path.join(dir_base, 'bower_components'),
    views: path.join(dir_base, 'views'),
    public: path.join(dir_base, 'public')
};
