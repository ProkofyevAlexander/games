var app = require('./index'),
    config = require('./config');

app.listen(config.express.port, config.express.ip,  function (err) {

    if (err) {
        console.log('Unable to listen for connections', err);
        process.exit(10);
    }

    console.log('Express is listening on ' + config.express.ip + ':' + config.express.port);
});