require.config({
    baseUrl: '/js/',
    paths: {
        'angular': '/angular/angular.min',
        'angular-leaflet-directive': '/angular-leaflet-directive/dist/angular-leaflet-directive.min',
        'leaflet': '/leaflet/dist/leaflet'
    },
    shim: {
        'app': {
            deps: ['angular', 'angular-leaflet-directive']
        },
        'angular-leaflet-directive': {
            deps: ['angular', 'leaflet']
        }
    }
});

require(['app'], function (app) {
    angular.bootstrap(document, ['app']);
});