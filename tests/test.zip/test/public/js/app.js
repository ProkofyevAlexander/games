'use strict';

var app = angular.module('app', ['leaflet-directive']);

app.controller('AppController', [
    '$scope',
    '$http',
    function ($scope, $http) {

        var paths = {};
        var icons = [];
        var svgMarker = null;

        $scope.pairsNum = 3;

        angular.extend($scope, {
            center: {
                lat: 56.31998,
                lng: 44.00801,
                zoom: 14
            },
            paths: {},
            markers: {},
            defaults: {}
        });

        $http.get('/ajax/marker')
            .success(function (data) {
                svgMarker = data.svgMarker;
            });

        var getIconWithClassName = function (className, rotateRad) {

            if (svgMarker == null) {
                return null;
            }

            return {
                iconUrl: svgMarker.replace('%5Brotate%5D', Math.round(rotateRad * 180 / Math.PI).toString()),
                iconSize: [0, 0],
                iconAnchor: [0, 0],
                className: className
            };
        };

        var iconSizes = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 10, 20, 30, 62, 128, 250, 500, 1000];

        var setupMarkers = function () {

            var iconSize = iconSizes[$scope.center.zoom] * 2;
            //console.log($scope.center.zoom);

            icons.forEach(function (icon) {
                icon[0].style.height = iconSize + 'px';
                icon[0].style.width = iconSize + 'px';
                icon[0].style.marginLeft = (- iconSize / 2) + 'px';
                icon[0].style.marginTop = (- iconSize / 2) + 'px';

                icon[1].style.height = (iconSize) + 'px';
                icon[1].style.width = (iconSize) + 'px';
                icon[1].style.marginLeft = (- iconSize / 2) + 'px';
                icon[1].style.marginTop = (- iconSize / 2) + 'px';
            });

        };

        $scope.setPoints = function () {

            var latRange = $scope.bounds.northEast.lat - $scope.bounds.southWest.lat;
            var lngRange = $scope.bounds.northEast.lng - $scope.bounds.southWest.lng;
            var markers = {};

            paths = {};

            for (var i = 0; i < $scope.pairsNum; i++) {

                var y0 = latRange * Math.random();
                var x0 = lngRange * Math.random();
                var y1 = latRange * Math.random();
                var x1 = lngRange * Math.random();

                var angle = Math.atan2(x0 - x1, y0 - y1);

                markers['marker_0_' + i] = {
                    lat: $scope.bounds.southWest.lat + y0,
                    lng: $scope.bounds.southWest.lng + x0,
                    //message: '',
                    icon: getIconWithClassName('icon-0-' + i, angle),
                    focus: false,
                    draggable: false
                };

                markers['marker_1_' + i] = {
                    lat: $scope.bounds.southWest.lat + y1,
                    lng: $scope.bounds.southWest.lng + x1,
                    //message: '',
                    icon: getIconWithClassName('icon-1-' + i, angle + Math.PI),
                    focus: false,
                    draggable: false
                };

                paths['path_' + i] = {
                    color: '#008000',
                    dashArray: '5, 10',
                    weight: 4,
                    latlngs: [
                        {lat: markers['marker_0_' + i].lat, lng: markers['marker_0_' + i].lng},
                        {lat: markers['marker_1_' + i].lat, lng: markers['marker_1_' + i].lng}
                    ],
                    angle: angle
                };
            }

            $scope.markers = markers;
            $scope.paths = paths;

            setTimeout(function () {

                icons = [];

                for (var i = 0; i < $scope.pairsNum; i++) {

                    icons.push([
                        document.getElementsByClassName('icon-0-' + i)[0],
                        document.getElementsByClassName('icon-1-' + i)[0]
                    ]);

                    setupMarkers();
                }
            }, 50);
        };

        $scope.$on('leafletDirectiveMap.my-map.zoomend', function () {
            setTimeout(function () {
                setupMarkers();
            }, 50);
        });

    }]);